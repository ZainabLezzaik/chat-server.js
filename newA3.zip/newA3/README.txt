Zainab Lezzaik 
101263105
INSTALL INSTRUCTIONS : after unzipping and before launching the server
                       execute the following command : npm install  (to install external modules)
INSTRUCTION TO LAUNCH : after unzipping the file (in root folder) 
                        execute this command : node server.js 
INSTRUCTIONS TO TEST : open several browsers of : http://localhost:3000/clientChat.html 
Node JS Version: v18.13.0
